#import <Flutter/Flutter.h>

@interface FileSaverPlugin : NSObject<FlutterPlugin>
@end
