## 1.0.3
* fix: Delay again plugin init because of binary messenger not initialized.

## 1.0.2
* chore: Update dependency app_links_platform_interface to 2.0.0+ because of breaking changes.

## 1.0.1
* fix: Package setup.

## 1.0.0
* chore: Initial release.
