import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryBlack = Color(0xFF101013);
  static const Color primaryRed = Color(0xFF8D0000);
}
